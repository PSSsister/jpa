package service;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;







import Exception.AccountNotExist;
import Exception.InsufficientBalanceException;
import bean.TransactionBean;
import bean.User;
import dao.PaymentWalletDaoImp;

public class PaymentWalletServiceImpl {
      PaymentWalletDaoImp dao=new PaymentWalletDaoImp();
      Scanner sc=new Scanner(System.in);
      public void userAccountCreate(User userbean)
      {
    	  dao.userAccountCreate(userbean);
      }
     public String showBalance(Integer accountId,String password)
     {
    	 String s =dao.showBalance(accountId, password);
    	 return s;
     }
     public String Deposit(Integer accountNo, String password, Integer amount)
     {
    	 String s =dao.Deposit(accountNo, password, amount);
    	 return s;
     }
     public String withDraw(Integer accountNo, String password, Integer amount)
     {
    	 String s=dao.withDraw(accountNo, password, amount);
    	 return s;
     }
 	public String fundTransfer(Integer accountNo, String password, Integer destAccountNo,Integer amount)
 	{
 		 String s=dao.fundTransfer(accountNo, password, destAccountNo, amount);
 		 return s;
 	}
 	public String printTransactions(Integer accountNo)
 	{
 		HashMap hm = dao.printTransactions(accountNo);
         Set s = hm.entrySet();
		
		Iterator i = s.iterator();
		String trans = "" ;
		while(i.hasNext()) {
			//Map<Integer, TransactionBean>.Entry<Integer,TransactionBean> pair = (Map.Entry<Integer, TransactionBean>) i.next(); 
			
			Map.Entry pair = (Map.Entry)i.next();
			
			int tid = (int) pair.getKey();
			System.out.println();
			TransactionBean tb = (TransactionBean) pair.getValue();
			
			trans = trans +"\n"+"transaction ID = "+tid+"|| Transaction Type = "+tb.getTransactionType()+" || Date = "+tb.getTransactiondate()+" || account id = "+tb.getAccountNo()+"|| amount = "+tb.getAmount()
					+" || to account id= "+tb.getToAccountId()+"\n";
			
		}
		
		return trans;
		
 	}
 	public  String nameCheck(String name) {
	       
		while(true) {
			
			try {
				if(name.matches("[A-Z a-z]{3,10}")) {
					return name;
				}
				else {
					
					throw new Exception();
				}
			}
			catch(Exception ex) {
				System.out.println("------------Input Error----------------");
				System.out.println("Please enter username where length is greater than 2 and less than 10.");
				System.out.println("Enter again:[Enter exit for dashboard]");
				name = sc.nextLine();
				if(name.equals("exit")) {
					return "exit";
				}
			}
		}
	}
	
	
	//this method validate password.
	public  String passwordCheck(String password) {
		while(true) {
			try {
				if(password.matches("^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{4,16}$")) {
					return password;
					
				}
				else {
					throw new Exception();
				}
			}
			catch(Exception ex){
				System.out.println("Please enter valid password(i.e-'Password123')");
				System.out.println("Enter again:[Enter exit for dashboard]");
				password = sc.nextLine();
				if(password.equals("exit")) {
					return "exit";
				}
			}
			
		}
	}
	
	//this method validate user mobile number.
	public String mobileNumberCheck(String mobileNumber) {
		while(true) {
			try {
				if(mobileNumber.matches("[6-9][0-9]{9}")) {
					return mobileNumber;
					
				}
				else {
					throw new Exception();
				}
			}
			catch(Exception ex){
				System.out.println("Enter valid mobile number(i.e - 10 digit only)");
				System.out.println("Enter again");
				mobileNumber = sc.nextLine();
				if(mobileNumber.equals("exit")) {
					return "exit";
				}
			}
			
		}
	}
	
	
	//this method check user enter amount limit.(not greater than 999999).
	public Integer amountLimitCheck(Integer amount) {
		while(true) {
			try {
				if(amount<=0) {
					throw new Exception();
				}
				else {
					return amount;
				}
			}
			catch(Exception ex){
				System.out.println("Enter valid amount.(less than 999999)");
				System.out.println("Enter again");
				amount = sc.nextInt();
				if(amount.equals(0)) {
					return 0;
				}
			}
		}
	}
	
	//this method check if account id present in collection or not.
	
	public Integer validAccountId(Integer accountNo) {
				if(dao.validAccountId(accountNo))
				{
					return accountNo;
				}
				else {
					throw new AccountNotExist("Invalid Account Number");
				}
			
	}
	
	//this method check balance in user account..

	public Integer checkBalance(Integer accountId,Integer amount) {
		if(dao.checkBalance(accountId, amount)) { //Here we transfer amount to DAO class.
			return amount;
		}
		else {
			throw new InsufficientBalanceException("Insufficient amount");
		}

	}
	
	

}
