package service;

import java.util.HashMap;

import bean.TransactionBean;
import bean.User;

public interface PaymentWalletService {
	void userAccountCreate(User userbean);
	String showBalance(Integer accountId,String password);
	String Deposit(Integer accountNo, String password, Integer amount);
	String withDraw(Integer accountNo, String password, Integer amount);
	String fundTransfer(Integer accountNo, String password, Integer destAccountNo,Integer amount);
	String printTransactions(Integer accountNo);
	
	//this all validation methods.
	String validAccountId(String accountNo);
	String checkBalance(String accountNo,String amount);
	String nameCheck(String userName);
	String passwordCheck(String password);
	String mobileNumberCheck(String mobileNumber);
	String amountLimitCheck(String amount);
}
