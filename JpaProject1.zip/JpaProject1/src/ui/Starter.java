package ui;

import java.util.Random;
import java.util.Scanner;



import service.PaymentWalletServiceImpl;
import dao.PaymentWalletDaoImp;
import Exception.AccountNotExist;
import bean.User;


public class Starter {
static void showDashbord() {
		
		System.out.println("*****Dashboard*****");
		System.out.println("1.Create account \n2.Show balance \n3.Deposit amount \n4.Withdraw Amount \n5.Fund Transfer \n6.Print Transaction \n7.Exit");
		
	}
    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
    	PaymentWalletDaoImp dao=new PaymentWalletDaoImp();
		PaymentWalletServiceImpl service=new PaymentWalletServiceImpl();
		while(true) {
			showDashbord();
			System.out.println("Enter choice:");
			String choice = sc.next();
			
		
			switch(choice) {
			case "1":
			  System.out.println("***Create Account***");
			 
				System.out.println("Enter user name:");
				String userName1 = sc.next();
				sc.nextLine();
				System.out.println("Enter your email id:");
				String emailId =sc.nextLine();
				sc.nextLine();
				System.out.println("Enter mobile number:");
				String phoneNo = sc.nextLine();
				sc.nextLine();
				String updateMobileNumber = service.mobileNumberCheck(phoneNo);//validation method for mobile number.
			 	
			 	 if(updateMobileNumber.equals("exit")) { // if service class return exit switch case will break.
		 			 System.out.println("this");
			 		 break;
		 		 }
				System.out.println("Enter password for account:");
				String password = sc.nextLine();
				String updatePassword = service.passwordCheck(password);//validation method for password.
			 	 if(updatePassword.equals("exit")) { 	// if service class return exit switch case will break.
		 			 break;
		 		 }
				Random random = new Random();
			    Integer accountNo = random.nextInt(1000000);
				User user=new User();
				user.setAccountNo(accountNo);
				user.setUserName(userName1);
	            user.setEmailId(emailId);
	            user.setPass(password);
	            user.setPhoneNo(phoneNo);
	            user.setBalance(0);
	            service.userAccountCreate(user);
	            System.out.println("Account created successfully");
	            break;
			case "2":
				 
				 System.out.println("***Show Balance***");
				 System.out.println("Enter account Number:");
				 Integer accountNo1=sc.nextInt();
				 sc.nextLine();
				 while(true) {
		 			 //this try-catch block throws user defined exception[AccountNotFoundException]
		 			 try {
		 				accountNo1 = service.validAccountId(accountNo1);
		 				 break;
		 			 }
		 			 catch(AccountNotExist e) {
		 				System.out.println(e);
		 				System.out.println("Enter again:[Enter exit for dashboard]");
		 				accountNo = sc.nextInt();
						if(accountNo.equals(0)) {
							accountNo = 0;
							break;
						}
		 			 }
		 		 }
				 System.out.println("Enter password for account:");
				 String password1 = sc.nextLine();
				System.out.println(service.showBalance(accountNo1, password1));
				break;
				
			case "3":
				 System.out.println("***Deposit balance***");
				 System.out.println("Enter account Number:");
				 Integer accountNo2=sc.nextInt();
				 sc.nextLine();
				 while(true) {
		 			 //this try-catch block throws user defined exception[AccountNotFoundException]
		 			 try {
		 				accountNo1 = service.validAccountId(accountNo2);
		 				 break;
		 			 }
		 			 catch(AccountNotExist e) {
		 				System.out.println(e);
		 				System.out.println("Enter again:[Enter exit for dashboard]");
		 				accountNo = sc.nextInt();
						if(accountNo.equals(0)) {
							accountNo = 0;
							break;
						}
		 			 }
		 		 }
				 System.out.println("Enter password for account:");
				 String password2 = sc.nextLine();
                 System.out.println("Enter amount you want to deposit");
                 Integer amount=sc.nextInt();
                 System.out.println(service.Deposit(accountNo2,password2,amount));
                 break;
			case "4":
				 System.out.println("***Withdraw balance***");
				 System.out.println("Enter account Number:");
				 Integer accountNo3=sc.nextInt();
				 sc.nextLine();
				 while(true) {
		 			 //this try-catch block throws user defined exception[AccountNotFoundException]
		 			 try {
		 				accountNo1 = service.validAccountId(accountNo3);
		 				 break;
		 			 }
		 			 catch(AccountNotExist e) {
		 				System.out.println(e);
		 				System.out.println("Enter again:[Enter exit for dashboard]");
		 				accountNo = sc.nextInt();
						if(accountNo.equals(0)) {
							accountNo = 0;
							break;
						}
		 			 }
		 		 }
				 System.out.println("Enter password for account:");
				 String password3 = sc.nextLine();
                 System.out.println("Enter amount you want to withdraw");
                 Integer amount1=sc.nextInt();
                 amount = service.amountLimitCheck(amount1);
			 		 if(amount.equals(0)) {
			 			 break;
			 		 }
                 System.out.println(service.withDraw(accountNo3, password3, amount1));
				 break;
			case "5":
				 System.out.println("***fund Transfer***");
				 System.out.println("Enter account Number:");
				 Integer accountNo4=sc.nextInt();
				 sc.nextLine();
				 while(true) {
		 			 //this try-catch block throws user defined exception[AccountNotFoundException]
		 			 try {
		 				accountNo1 = service.validAccountId(accountNo4);
		 				 break;
		 			 }
		 			 catch(AccountNotExist e) {
		 				System.out.println(e);
		 				System.out.println("Enter again:[Enter exit for dashboard]");
		 				accountNo = sc.nextInt();
						if(accountNo.equals(0)) {
							accountNo = 0;
							break;
						}
		 			 }
		 		 }
				 System.out.println("Enter password for account:");
				 String password4 = sc.nextLine();
                 System.out.println("Enter amount you want to transfer");
                 Integer amount3=sc.nextInt();
                 amount = service.amountLimitCheck(amount3);
			 		 if(amount.equals(0)) {
			 			 break;
			 		 }
                 System.out.println("Enter destination account Number:");
				 Integer destAccountNo=sc.nextInt();
				 sc.nextLine();
			     System.out.println(service.fundTransfer(accountNo4, password4, destAccountNo, amount3)); 
			     break;
			case "6":
				 System.out.println("***Print Transaction***");
				 System.out.println("Enter account Number:");
				 Integer accountNo5=sc.nextInt();
				 sc.nextLine();
				 while(true) {
		 			 //this try-catch block throws user defined exception[AccountNotFoundException]
		 			 try {
		 				accountNo1 = service.validAccountId(accountNo5);
		 				 break;
		 			 }
		 			 catch(AccountNotExist e) {
		 				System.out.println(e);
		 				System.out.println("Enter again:[Enter exit for dashboard]");
		 				accountNo = sc.nextInt();
						if(accountNo.equals(0)) {
							accountNo = 0;
							break;
						}
		 			 }
		 		 }
				 System.out.println(service.printTransactions(accountNo5));
				 break;
			case "7":
				System.out.println("Thank you");
				System.exit(0);
				break;
		    default:
		        System.out.println("wrong input");
			
}
}
    }
}
